namespace Диплом
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public static int i = 0;
        public static int res1=0;
        public static int res2=0;
        public static int res3=0; 
        public static int res4=0; 
        public static int res5=0;
        

        public Form1()
        {
            InitializeComponent();
           
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void criteries_Click(object sender, EventArgs e)
        {
            this.Hide();
            Критерии критерии = new Критерии();
            критерии.ShowDialog();
           
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void start_Click(object sender, EventArgs e)
        {
            this.Hide();
            Вопрос Вопрос = new Вопрос();
            Вопрос.ShowDialog();
        }
    }
}