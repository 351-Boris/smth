﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Вопрос39 : Form
    {
        public Вопрос39()
        {
            InitializeComponent();
            label3.Text =Form1.i.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true && checkBox1.Checked==true)
            {
                Form1.i = Form1.i + 1;
                Form1.res4 = Form1.res4+1;
            }
            this.Hide();
            Вопрос39_1 Вопрос39_1 = new Вопрос39_1();
            Вопрос39_1.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
