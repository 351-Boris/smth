﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Результаты : Form
    {
        public Результаты()
        {
            InitializeComponent();
            label3.Text=(Form1.res1*10).ToString()+"%";
            label5.Text=(Form1.res2*10).ToString()+"%";
            label7.Text=(Form1.res3*10).ToString()+"%";
            label9.Text=(Form1.res4*10).ToString()+"%";
            label11.Text=(Form1.res5*10).ToString()+"%";
            label13.Text=(Form1.i*2).ToString()+"%";
            int res = Form1.res1*10+Form1.res2*10+Form1.res3*10+Form1.res4*10+Form1.res5*10;
            if(res>=450)
            {
                label15.Text="Высшая степень";
                
            }
            else if(res>=400 && res<450)
            {
                label15.Text="Продвинутая степень";
            }
            else if(res>=350 && res<400)
            {
                label15.Text="Средняя степень";
            }
            else if (res>=300 && res<350)
            {
                label15.Text="Низшая степень";
            }
            else if ( res<300)
            {
                label15.Text="Степени нет";
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Результаты_Load(object sender, EventArgs e)
        {

        }
    }
}
