﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Вопрос : System.Windows.Forms.Form
    {
        public Вопрос()
        {
            InitializeComponent();
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked==true)
            {
                Form1.i=Form1.i+1;
                Form1.res1 = Form1.res1+1;
            }
            this.Hide();
            Вопрос2 Вопрос2 = new Вопрос2();
            Вопрос2.ShowDialog();

        }
        
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Вопрос_Load(object sender, EventArgs e)
        {
            label3.Text = Form1.i.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
        }
    }
}
