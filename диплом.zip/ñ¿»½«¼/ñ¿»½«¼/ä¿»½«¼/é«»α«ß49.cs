﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Вопрос49 : Form
    {
        public Вопрос49()
        {
            InitializeComponent();
            label3.Text =Form1.i.ToString();

        }

        private void Вопрос49_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox3.Checked == true)
            {
                Form1.i = Form1.i + 1;
                Form1.res5 = Form1.res5+1;
            }
            this.Hide();
            Вопрос50 Вопрос50 = new Вопрос50();
            Вопрос50.ShowDialog();
        }
    }
}
