﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Вопрос8 : System.Windows.Forms.Form
    {
        public Вопрос8()
        {
            InitializeComponent();
            label3.Text =Form1.i.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ( checkBox3.Checked == true && checkBox4.Checked == true)
            {
                Form1.i = Form1.i + 1;
                Form1.res1 = Form1.res1+1;
            }
            this.Hide();
            Вопрос9 Вопрос9 = new Вопрос9();
            Вопрос9.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
