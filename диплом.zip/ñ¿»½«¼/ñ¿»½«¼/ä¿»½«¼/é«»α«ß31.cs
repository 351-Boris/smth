﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Вопрос31 : Form
    {
        public Вопрос31()
        {
            InitializeComponent();
            label3.Text =Form1.i.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true && checkBox3.Checked == true && checkBox2.Checked == true)
            {
                Form1.i = Form1.i + 1;
                Form1.res4 = Form1.res4+1;
            }
            this.Hide();
            Вопрос32 Вопрос32 = new Вопрос32();
            Вопрос32.ShowDialog();
        }
    }
}
