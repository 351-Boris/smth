﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Вопрос18 : Form
    {
        public Вопрос18()
        {
            InitializeComponent();
            label3.Text= Form1.i.ToString();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                Form1.i = Form1.i + 1;
                Form1.res2 = Form1.res2+1;
            }
            this.Hide();
            Вопрос19 Вопрос19 = new Вопрос19();
            Вопрос19.ShowDialog();
        }
    }
}
