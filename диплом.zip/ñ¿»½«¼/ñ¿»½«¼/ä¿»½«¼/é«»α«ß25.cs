﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Вопрос25 : Form
    {
        public Вопрос25()
        {
            InitializeComponent();
            label3.Text= Form1.i.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                Form1.i = Form1.i + 1;
                Form1.res3 = Form1.res3+1;
            }
            this.Hide();
            Вопрос26 Вопрос26 = new Вопрос26();
            Вопрос26.ShowDialog();
        }
    }
}
