﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Диплом
{
    public partial class Вопрос9 : System.Windows.Forms.Form
    {
        public Вопрос9()
        {
            InitializeComponent();
            label3.Text = Form1.i.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true && checkBox2.Checked ==true && checkBox3.Checked == true && checkBox4.Checked == true && checkBox5.Checked==true)
            {
                Form1.i = Form1.i + 1;
                Form1.res1 = Form1.res1+1;
            }
            this.Hide();
            Вопрос10 Вопрос10 = new Вопрос10();
            Вопрос10.ShowDialog();
        }

        private void Вопрос9_Load(object sender, EventArgs e)
        {

        }
    }
}
